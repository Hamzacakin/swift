import UIKit

var greeting = "Hello, playground"
let character = "Daphne"
print(character)
print(greeting)

let actor = "Denzel Washington"
let quote = "Then he tapped a sign saying \"Believe\" and walked away."
let movie = """
a day in
the life of an
Apple engineer
"""
print(actor.count)
print(quote.count)
print(movie.uppercased())

var counter = 5
counter = counter + 5
print(counter)

var counterPlus = counter + 5
print(counterPlus)

var yeniSayi = counterPlus * counter
print(yeniSayi)

var yeniSayininYarisi = yeniSayi / 2

var number = 120
print(number.isMultiple(of: 4))

print(23456.isMultiple(of: 34))

print(34.isMultiple(of: 17))

var number2 = 0.1 + 0.2

let a = 1
let b = 2.0
let c = a * Int(b)

var name = "Nicolas"
name = "57"

var rating = 5.0
rating *= 2

let myInt = 1
let myInt2 = 1.0




